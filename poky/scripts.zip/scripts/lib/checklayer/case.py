# Copyright (C) 2017 Intel Corporation
#
# SPDX-License-Identifier: MIT
#

from oeqa.core.case import OETestCase

class OECheckLayerTestCase(OETestCase):
    pass
