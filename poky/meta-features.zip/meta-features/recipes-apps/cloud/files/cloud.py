#cloud.py
import time
import random
import json
import boto3
from AWSIoTPythonSDK.MQTTLib import AWSIoTMQTTClient
import threading
import requests
import mysql.connector
import serial
import pynmea2

class GPSReader:
    def __init__(self, port="/dev/serial1", baud=9600):
        self.lat = self.lon = self.speed_kmh = None
        self._ser = serial.Serial(port, baud, timeout=1)
        self._run = True
        threading.Thread(target=self._poll, daemon=True).start()

    def _poll(self):
        while self._run:
            try:
                line = self._ser.readline().decode('utf-8', errors='replace')
                if line.startswith('$GPGGA') or line.startswith('$GPRMC'):
                    msg = pynmea2.parse(line)
                    if hasattr(msg, 'latitude') and hasattr(msg, 'longitude'):
                        self.lat = msg.latitude
                        self.lon = msg.longitude
                    if hasattr(msg, 'spd_over_grnd') and msg.spd_over_grnd is not None:
                        self.speed_kmh = msg.spd_over_grnd * 1.852  # convert knots to km/h
            except pynmea2.ParseError:
                continue
            except serial.SerialException as e:
                print(f"Serial exception: {e}")
                break

    def stop(self):
        self._run = False
        try:
            self._ser.close()
        except Exception:
            pass
# ---------------------------------------------------------------------

# Configure the IoT Core client
client = AWSIoTMQTTClient("SimulatedDevice")
client.configureEndpoint("a2d2r7fkbluzpl-ats.iot.us-east-1.amazonaws.com", 8883)
client.configureCredentials(
    "/opt/cloud/root-ca.pem",
    "/opt/cloud/private.pem.key",
    "/opt/cloud/certificate.pem.crt"
)
client.connect()

# Configure the S3 and SNS clients
s3 = boto3.client('s3', region_name='us-east-1')
sns_client = boto3.client('sns', region_name='us-east-1')

# SNS Topics
acceleration_alert_topic = "arn:aws:sns:us-east-1:060795930163:acceleration_alert_topic"
speed_violation_alert_topic = "arn:aws:sns:us-east-1:060795930163:speed_violation_alerts"

# Buckets for saving data
bucket_name = "car-data-eda"
accident_records_bucket = "project-accedants-total-records"

# Accident threshold
THRESHOLD_ACCELERATION = -50

# MySQL RDS Configuration
rds_config = {
    "host": "accidant-database.cl8ayk82e3xy.us-east-1.rds.amazonaws.com",
    "user": "admin",
    "password": "1102002asd",
    "database": "accidant-database"
}

def save_accident_data_to_rds(data):
    try:
        connection = mysql.connector.connect(**rds_config)
        cursor = connection.cursor()
        insert_query = """
        INSERT INTO accident_records (timestamp, acceleration, velocity, latitude, longitude)
        VALUES (%s, %s, %s, %s, %s)
        """
        values = (data['timestamp'], data['acceleration'], data['velocity'], data['latitude'], data['longitude'])
        cursor.execute(insert_query, values)
        connection.commit()
        cursor.close()
        connection.close()
        print("Accident data saved to MySQL RDS successfully.")
    except Exception as e:
        print("Error saving accident data to MySQL RDS:", e)

def get_max_speed(latitude, longitude):
    url = f"https://overpass-api.de/api/interpreter?data=[out:json];way(around:50,{latitude},{longitude})['maxspeed'];out;"
    try:
        response = requests.get(url)
        data = response.json()
        speeds = [int(element['tags']['maxspeed']) for element in data['elements']
                  if 'tags' in element and 'maxspeed' in element['tags']]
        return min(speeds) if speeds else 60
    except Exception as e:
        print("Error fetching speed limit:", e)
        return 60

def send_speed_violation_sns_message(violation_type, vehicle_speed, max_speed):
    try:
        message = (f"Speed Violation Alert: Your speed ({vehicle_speed} km/h) "
                   f"exceeds the road speed limit ({max_speed} km/h). {violation_type}")
        sns_client.publish(TopicArn=speed_violation_alert_topic,
                           Subject="Speed Violation Alert", Message=message)
        print("Speed Violation SNS message sent successfully.")
    except Exception as e:
        print("Error sending speed violation SNS message:", e)

def send_accident_sns_message(latitude, longitude):
    try:
        message = f"Warning! Accident detected. Location: Latitude {latitude}, Longitude {longitude}"
        sns_client.publish(TopicArn=acceleration_alert_topic,
                           Subject="Accident Alert", Message=message)
        print("Accident SNS message sent successfully.")
    except Exception as e:
        print("Error sending accident SNS message:", e)

def save_accident_data_to_s3(bucket_name, data):
    try:
        file_name = f"accident-{int(time.time())}.csv"
        csv_content = "timestamp,acceleration,velocity,latitude,longitude\n"
        csv_content += (f"{data['timestamp']},{data['acceleration']},{data['velocity']},"
                        f"{data['latitude']},{data['longitude']}")
        s3.put_object(Bucket=bucket_name, Key=file_name, Body=csv_content,
                      ContentType="text/csv")
        print(f"Accident data uploaded to S3: {file_name}")
    except Exception as e:
        print("Error saving accident data to S3:", e)

# Initialize the GPS reader
gps = GPSReader(port="/dev/serial1", baud=9600)

# Main loop
try:
    while True:
        try:
            latitude = gps.lat
            longitude = gps.lon
            car_speed = gps.speed_kmh

            if None in (latitude, longitude, car_speed):
                time.sleep(1)
                continue

            max_speed_limit = get_max_speed(latitude, longitude)
            acceleration = random.uniform(-60, -10)

            data = {
                "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "acceleration": acceleration,
                "velocity": car_speed,
                "latitude": latitude,
                "longitude": longitude
            }

            if car_speed > max_speed_limit and random.random() < 0.1:
                threading.Thread(
                    target=send_speed_violation_sns_message,
                    args=("Please reduce your speed", car_speed, max_speed_limit)
                ).start()

            if acceleration < THRESHOLD_ACCELERATION and random.random() < 0.1:
                threading.Thread(
                    target=send_accident_sns_message,
                    args=(latitude, longitude)
                ).start()
                save_accident_data_to_s3(bucket_name, data)
                save_accident_data_to_rds(data)

            client.publish("device/topic", json.dumps(data), 1)
            print("Data published to AWS IoT Core:", data)

            time.sleep(5)
        except Exception as e:
            print("Error in main loop:", e)
except KeyboardInterrupt:
    print("Stopping…")
finally:
    gps.stop()
    client.disconnect()
#/home/CloudyDrive/Downloads/root-Ca.pem  
#/home/CloudyDrive/Downloads/private.pem.key
#/home/CloudyDrive/Downloads/certificate.pem.crt
#mysql -h accidant-database.cl8ayk82e3xy.us-east-1.rds.amazonaws.com -u admin -p
