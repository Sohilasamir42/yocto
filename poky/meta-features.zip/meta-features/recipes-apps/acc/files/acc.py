import time
import serial
import signal
import sys
from rplidar import RPLidar
from multiprocessing import Process, Queue
import struct

# Define front-center zone for ACC (angles in degrees)
ZONES = {
    "FC": (150, 210),  # Front-Center (spanning 330°–360° and 0°–30°)
}

# Danger zone thresholds in mm
DANGER_ZONE_MIN = 150   # 0.15 meters
SAFE_ZONE_MAX = 7000    # 7 meters

# UART configuration
UART_PORT = "/dev/serial1"  # Raspberry Pi UART port
BAUD_RATE = 9600            # Baud rate for UART communication

MAX_UART_RETRIES = 3  # Max retries for UART communication

# Shared queue for inter-process communication
data_queue = Queue()

# Signal handler for safe shutdown
def signal_handler(sig, frame):
    print("\nStopping processes safely...")
    acquisition_process.terminate()
    processing_process.terminate()
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)  # Handle Ctrl+C

def lidar_acquisition(queue):
    """Process 1: Acquire LiDAR data and put it in the queue."""
    try:
        lidar = RPLidar('/dev/ttyUSB0')  # Ensure correct port
        print("LiDAR started successfully.")
        
        lidar.stop()
        lidar.clean_input()
        lidar.start_motor()

        for scan in lidar.iter_scans():
            lidar.clean_input()
            queue.put(scan)  # Send scan data to processing process

    except Exception as e:
        print(f"LiDAR acquisition error: {e}")
    
    finally:
        print("Stopping LiDAR...")
        lidar.stop()
        lidar.stop_motor()
        lidar.disconnect()

def clear_queue(queue):
    """Clears all items from the queue."""
    while not queue.empty():
        queue.get()

def lidar_processing(queue):
    """Process 2: Process LiDAR data and send detection results over UART."""
    uart = serial.Serial(UART_PORT, BAUD_RATE, timeout=1)
    print("UART initialized.")

    def send_uart_message(zone_data):
        """Send structured data over UART with retry logic."""
        retries = 0
        while retries < MAX_UART_RETRIES:
            if uart.is_open:
                try:
                    packed_data = struct.pack('<H', *zone_data)  # Only FC
                    uart.write(packed_data)
                    print(f"Sent over UART: {zone_data}")
                    return  # Successfully sent
                except serial.SerialException as e:
                    print(f"UART Error: {e}")
                    retries += 1
                    time.sleep(0.1)
        print("UART failed after max retries. Stopping communication.")

    while True:
        try:
            scan = queue.get(timeout=1)  # Blocks until new data arrives
        except:
            continue  # Skip if no new data

        zone_values = []
        for zone, (start_angle, end_angle) in ZONES.items():
            nearest_distance = SAFE_ZONE_MAX + 1
            for (_, angle, distance) in scan:
                if (start_angle <= angle <= 360 or 0 <= angle <= end_angle) and DANGER_ZONE_MIN <= distance <= SAFE_ZONE_MAX:
                    nearest_distance = min(nearest_distance, distance)
            zone_values.append(int(nearest_distance) if nearest_distance <= SAFE_ZONE_MAX else 0)

        send_uart_message(zone_values)
        clear_queue(queue)
        time.sleep(3)

if __name__ == "__main__":
    acquisition_process = Process(target=lidar_acquisition, args=(data_queue,))
    processing_process = Process(target=lidar_processing, args=(data_queue,))
    acquisition_process.start()
    processing_process.start()
    acquisition_process.join()
    processing_process.join()
