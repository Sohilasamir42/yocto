#the content of blindspot.py
import time
import serial
import signal
import sys
from rplidar import RPLidar
from multiprocessing import Process, Queue
import struct

# Define zones (angles in degrees)
ZONES = {
    "RL": (30, 60),    # Front-Left
    "RR": (300, 330),  # Front-Right
    "FL": (120, 150),  # Rear-Left
    "FR": (210, 240),  # Rear-Right
}

# Danger zone thresholds in mm
DANGER_ZONE_MIN = 150   # 0.15 meters
SAFE_ZONE_MAX = 7000    # 7 meters

# UART configuration
UART_PORT = "/dev/serial1"
BAUD_RATE = 9600
MAX_UART_RETRIES = 3

# Debug mode (disable UART if True)
DEBUG_MODE = True  # ✅ خليه False لو STM متوصل

# Shared queue
data_queue = Queue()

# Signal handler
def signal_handler(sig, frame):
    print("\nStopping processes safely...")
    acquisition_process.terminate()
    processing_process.terminate()
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)

def lidar_acquisition(queue):
    """Acquire LiDAR data and put it in the queue."""
    try:
        lidar = RPLidar('/dev/ttyUSB0')
        print("LiDAR started successfully.")

        lidar.stop()
        lidar.clean_input()
        lidar.start_motor()

        for scan in lidar.iter_scans():
            lidar.clean_input()
            queue.put(scan)

    except Exception as e:
        print(f"LiDAR acquisition error: {e}")

    finally:
        print("Stopping LiDAR...")
        lidar.stop()
        lidar.stop_motor()
        lidar.disconnect()

def clear_queue(queue):
    """Clears all items from the queue."""
    while not queue.empty():
        try:
            queue.get_nowait()
        except:
            break

def lidar_processing(queue):
    """Process LiDAR data and send detection results over UART or print in debug."""
    uart = None

    if not DEBUG_MODE:
        try:
            uart = serial.Serial(UART_PORT, BAUD_RATE, timeout=1)
            print("UART initialized.")
        except Exception as e:
            print(f"⚠️ UART init failed: {e}. Running in debug mode instead.")
            uart = None

    else:
        print("Running in DEBUG mode. UART is disabled.")

    def send_uart_message(zone_data):
        """Send structured data or print in debug."""
        if DEBUG_MODE or uart is None:
            print(f"[DEBUG] Zone data: {zone_data}")
            return

        retries = 0
        while retries < MAX_UART_RETRIES:
            if uart.is_open:
                try:
                    packed_data = struct.pack('<4H', *zone_data)
                    uart.write(packed_data)
                    print(f"Sent over UART: {zone_data}")
                    return
                except serial.SerialException as e:
                    print(f"UART Error: {e}")
                    retries += 1
                    try:
                        uart.close()
                        uart.open()
                    except Exception as e:
                        print(f"Failed to re-open UART: {e}")
                        break
        print("UART failed after max retries. Stopping communication.")

    while True:
        try:
            scan = queue.get(timeout=1)
        except:
            continue

        zone_values = []

        for zone, (start_angle, end_angle) in ZONES.items():
            nearest_distance = SAFE_ZONE_MAX + 1

            for (_, angle, distance) in scan:
                if start_angle <= angle <= end_angle and DANGER_ZONE_MIN <= distance <= SAFE_ZONE_MAX:
                    nearest_distance = min(nearest_distance, distance)

            zone_values.append(int(nearest_distance) if nearest_distance <= SAFE_ZONE_MAX else 0)

        zone_values = [int(val) if isinstance(val, (int, float)) else 0 for val in zone_values]

        send_uart_message(zone_values)

        clear_queue(queue)
        time.sleep(3)

if __name__ == "__main__":
    acquisition_process = Process(target=lidar_acquisition, args=(data_queue,))
    processing_process = Process(target=lidar_processing, args=(data_queue,))

    acquisition_process.start()
    processing_process.start()

    acquisition_process.join()
    processing_process.join()
