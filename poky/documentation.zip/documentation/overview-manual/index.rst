.. SPDX-License-Identifier: CC-BY-SA-2.0-UK

==========================================
Yocto Project Overview and Concepts Manual
==========================================

|

.. toctree::
   :caption: Table of Contents
   :numbered:

   intro
   yp-intro
   development-environment
   concepts

.. include:: /boilerplate.rst
