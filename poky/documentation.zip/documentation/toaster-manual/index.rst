.. SPDX-License-Identifier: CC-BY-SA-2.0-UK

===================
Toaster User Manual
===================

|

.. toctree::
   :caption: Table of Contents
   :numbered:

   intro
   start
   setup-and-use
   reference

.. include:: /boilerplate.rst
