#!/bin/sh
echo "Third file" > $1/selftest-replaceme-scripted

