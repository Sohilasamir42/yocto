STRING = "pseudo_pyc_test2"
