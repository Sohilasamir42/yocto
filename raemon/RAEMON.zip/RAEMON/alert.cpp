// #include "alert.h"

// Alert::Alert(QObject *parent) : QObject(parent), m_notificationType("l") {}

// QString Alert::notificationType() const {
//     return m_notificationType;
// }

// void Alert::setNotificationType(const QString &type) {
//     if (type != m_notificationType) {
//         m_notificationType = "f";
//         emit notificationTypeChanged();
//     }
// }
