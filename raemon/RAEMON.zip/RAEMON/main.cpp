// //https://www.figma.com/design/Ytk3WPtb3oO9QNKm0IwoXV/Steely-Wheels---tvOS-App-(Community)?node-id=22-190&t=8zStTzYABNmcMAeO-0
// //https://www.figma.com/design/TnfgSUpsAM6lcpu1r5iuXm/Electric-Car-Console-UI-Design?node-id=1-2&t=hpdQh6sCITeI619F-0
// #include <QGuiApplication>
// #include <QQmlApplicationEngine>
// #include <QIcon>
// int main(int argc, char *argv[])
// {
//     qputenv("QT_IM_MODULE", QByteArray("qtvirtualkeyboard"));
// #if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
//     QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
// #endif
//     QCoreApplication::setOrganizationDomain("techcoderhub.com");
//     QCoreApplication::setOrganizationName("TechCoderHub");
//     QCoreApplication::setApplicationName("Raemon");

//     QGuiApplication app(argc, argv);

//     app.setWindowIcon(QIcon("qrc:/assets/techcoderhub_logo.jpg"));
//     const QUrl style(QStringLiteral("qrc:/Style.qml"));
//     qmlRegisterSingletonType(style, "Style", 1, 0, "Style");

//     QQmlApplicationEngine engine;
//     const QUrl url(QStringLiteral("qrc:/main.qml"));
//     QObject::connect(
//         &engine,
//         &QQmlApplicationEngine::objectCreated,
//         &app,
//         [url](QObject *obj, const QUrl &objUrl) {
//             if (!obj && url == objUrl)
//                 QCoreApplication::exit(-1);
//         },
//         Qt::QueuedConnection);
//     engine.load(url);

//     return app.exec();
// }

#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QIcon>
// #include "forward_collision.h"
// #include "lane.h"
// #include "adaptive.h"
// #include "alert.h"
#include "NotificationManager.h"


#include "features.h"



int main(int argc, char *argv[])
{
    // Virtual keyboard environment
    qputenv("QT_IM_MODULE", QByteArray("qtvirtualkeyboard"));

#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
#endif

    // Set organization and app details
    QCoreApplication::setOrganizationDomain("techcoderhub.com");
    QCoreApplication::setOrganizationName("TechCoderHub");
    QCoreApplication::setApplicationName("Raemon");

    QGuiApplication app(argc, argv);
    app.setWindowIcon(QIcon("qrc:/assets/techcoderhub_logo.jpg"));

    // Register Style singleton
    const QUrl styleUrl(QStringLiteral("qrc:/Style.qml"));
    qmlRegisterSingletonType(styleUrl, "Style", 1, 0, "Style");

    // Load QML engine
    QQmlApplicationEngine engine;

    // Expose backend class
    // ForwardCollision forwardCollision;
    // forwardCollision.loadCollisionStatus();

    // Lane lane;
    // lane.loadLaneStatus();

    // Adaptive adaptive;
    // adaptive.loadAdaptiveStatus();
     //Alert alert;
 NotificationManager notificationManager;
  notificationManager.loadNotificationType();
 Features features;
 features.loadFeatures();

    // engine.rootContext()->setContextProperty("forwardCollision", &forwardCollision);

    // engine.rootContext()->setContextProperty("lane", &lane);
    // engine.rootContext()->setContextProperty("adaptive", &adaptive);
 //   engine.rootContext()->setContextProperty("alert", &alert);
    engine.rootContext()->setContextProperty("notificationManager", &notificationManager);
 engine.rootContext()->setContextProperty("features", &features);


    // Set main QML file
    const QUrl mainQmlUrl(u"qrc:/main.qml"_qs);

    // Handle load failure
    QObject::connect(
        &engine, &QQmlApplicationEngine::objectCreated,
        &app, [mainQmlUrl](QObject *obj, const QUrl &objUrl) {
            if (!obj && mainQmlUrl == objUrl)
                QCoreApplication::exit(-1);
        }, Qt::QueuedConnection
        );

    engine.load(mainQmlUrl);


    return app.exec();
}
