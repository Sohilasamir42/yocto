#include "features.h"
#include <QFile>
#include <QJsonDocument>
#include <QJsonObject>
#include <QDebug>
#include <QStandardPaths>
#include <QDir>

Features::Features(QObject *parent)
    : QObject(parent)
{
}

int Features::adaptiveStatus() const { return m_adaptiveStatus; }
void Features::setAdaptiveStatus(int status) {
    if (m_adaptiveStatus != status) {
        m_adaptiveStatus = status;
        emit adaptiveStatusChanged();
    }
}

int Features::collisionStatus() const { return m_collisionStatus; }
void Features::setCollisionStatus(int status) {
    if (m_collisionStatus != status) {
        m_collisionStatus = status;
        emit collisionStatusChanged();
    }
}

int Features::laneStatus() const { return m_laneStatus; }
void Features::setLaneStatus(int status) {
    if (m_laneStatus != status) {
        m_laneStatus = status;
        emit laneStatusChanged();
    }
}

void Features::saveFeatures()
{
    QString path = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    QDir dir(path);
    if (!dir.exists())
        dir.mkpath(".");

    QFile file(dir.filePath("features.json"));
    if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
        qWarning() << "Failed to open features.json for writing.";
        return;
    }

    QJsonObject obj;
    obj["adaptiveStatus"] = m_adaptiveStatus;
    obj["collisionStatus"] = m_collisionStatus;
    obj["laneStatus"] = m_laneStatus;

    QJsonDocument doc(obj);
    file.write(doc.toJson());
    file.close();
    qDebug() << "Saved features to:" << file.fileName();
}

void Features::loadFeatures()
{
    QString path = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    QFile file(QDir(path).filePath("features.json"));

    if (!file.exists()) {
        qWarning() << "features.json does not exist. Creating default.";
        saveFeatures();
        return;
    }

    if (!file.open(QIODevice::ReadOnly)) {
        qWarning() << "Failed to open features.json for reading.";
        return;
    }

    QByteArray data = file.readAll();
    file.close();

    QJsonDocument doc = QJsonDocument::fromJson(data);
    if (!doc.isObject()) {
        qWarning() << "Invalid JSON format in features.json";
        return;
    }

    QJsonObject obj = doc.object();
    if (obj.contains("adaptiveStatus")) setAdaptiveStatus(obj["adaptiveStatus"].toInt());
    if (obj.contains("collisionStatus")) setCollisionStatus(obj["collisionStatus"].toInt());
    if (obj.contains("laneStatus")) setLaneStatus(obj["laneStatus"].toInt());
}
