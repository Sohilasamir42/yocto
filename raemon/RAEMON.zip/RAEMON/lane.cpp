// // #include "lane.h"

// // Lane::Lane(QObject *parent)
// //     : QObject(parent), m_laneStatus(0) {}

// // int Lane::laneStatus() const {
// //     return m_laneStatus;
// // }

// // void Lane::setLaneStatus(int status) {
// //     if (m_laneStatus != status) {
// //         m_laneStatus = status;
// //         emit laneStatusChanged();
// //     }
// // }


// #include "lane.h"
// #include <QFile>
// #include <QJsonDocument>
// #include <QJsonObject>
// #include <QDebug>
// #include <QStandardPaths>
// #include <QDir>

// Lane::Lane(QObject *parent)
//     : QObject(parent), m_laneStatus(0)
// {
// }

// int Lane::laneStatus() const
// {
//     return m_laneStatus;
// }

// void Lane::setLaneStatus(int status)
// {
//     if (m_laneStatus != status) {
//         m_laneStatus = status;
//         emit laneStatusChanged();
//     }
// }

// void Lane::saveLaneStatus()
// {
//     QString path = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
//     QDir dir(path);

//     if (!dir.exists()) {
//         dir.mkpath(".");
//     }

//     QFile file(dir.filePath("lane_flags.json"));

//     if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
//         qWarning() << "Failed to open file for writing at" << file.fileName();
//         return;
//     }
//     qDebug() << "Saving to:" << file.fileName();

//     QJsonObject obj;
//     obj["laneStatus"] = m_laneStatus;

//     QJsonDocument doc(obj);
//     file.write(doc.toJson());
//     file.close();
// }

// void Lane::loadLaneStatus()
// {
//     QString path = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
//     QFile file(QDir(path).filePath("lane_flags.json"));

//     if (!file.exists()) {
//         qWarning() << "File does not exist. Creating a new file.";
//         saveLaneStatus();
//         return;
//     }

//     if (!file.open(QIODevice::ReadOnly)) {
//         qWarning() << "Failed to open file for reading at" << file.fileName();
//         return;
//     }

//     QByteArray data = file.readAll();
//     file.close();

//     QJsonDocument doc = QJsonDocument::fromJson(data);
//     if (!doc.isObject()) {
//         qWarning() << "Invalid JSON format";
//         return;
//     }

//     QJsonObject obj = doc.object();
//     if (obj.contains("laneStatus")) {
//         setLaneStatus(obj["laneStatus"].toInt());
//     }
// }
