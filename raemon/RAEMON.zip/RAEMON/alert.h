// #ifndef ALERT_H
// #define ALERT_H

// #include <QObject>

// class Alert : public QObject
// {
//     Q_OBJECT
//     Q_PROPERTY(QString notificationType READ notificationType WRITE setNotificationType NOTIFY notificationTypeChanged)

// public:
//     explicit Alert(QObject *parent = nullptr);

//     QString notificationType() const;
//     void setNotificationType(const QString &type);

// signals:
//     void notificationTypeChanged();

// private:
//     QString m_notificationType;
// };

// #endif // ALERT_H
