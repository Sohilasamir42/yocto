// // #include "adaptive.h"

// // Adaptive::Adaptive(QObject *parent)
// //     : QObject(parent), m_adaptiveStatus(0) {}

// // int Adaptive::adaptiveStatus() const {
// //     return m_adaptiveStatus;
// // }

// // void Adaptive::setAdaptiveStatus(int status) {
// //     if (m_adaptiveStatus != status) {
// //         m_adaptiveStatus = status;
// //         emit adaptiveStatusChanged();
// //     }
// // }


// #include "adaptive.h"
// #include <QFile>
// #include <QJsonDocument>
// #include <QJsonObject>
// #include <QDebug>
// #include <QStandardPaths>
// #include <QDir>

// Adaptive::Adaptive(QObject *parent)
//     : QObject(parent), m_adaptiveStatus(0)
// {
// }

// int Adaptive::adaptiveStatus() const
// {
//     return m_adaptiveStatus;
// }

// void Adaptive::setAdaptiveStatus(int status)
// {
//     if (m_adaptiveStatus != status) {
//         m_adaptiveStatus = status;
//         emit adaptiveStatusChanged();
//     }
// }

// void Adaptive::saveAdaptiveStatus()
// {
//     QString path = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
//     QDir dir(path);

//     if (!dir.exists()) {
//         dir.mkpath(".");
//     }

//     QFile file(dir.filePath("adaptive_flags.json"));

//     if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
//         qWarning() << "Failed to open file for writing at" << file.fileName();
//         return;
//     }
//     qDebug() << "Saving to:" << file.fileName();

//     QJsonObject obj;
//     obj["adaptiveStatus"] = m_adaptiveStatus;

//     QJsonDocument doc(obj);
//     file.write(doc.toJson());
//     file.close();
// }

// void Adaptive::loadAdaptiveStatus()
// {
//     QString path = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
//     QFile file(QDir(path).filePath("adaptive_flags.json"));

//     if (!file.exists()) {
//         qWarning() << "File does not exist. Creating a new file.";
//         saveAdaptiveStatus();
//         return;
//     }

//     if (!file.open(QIODevice::ReadOnly)) {
//         qWarning() << "Failed to open file for reading at" << file.fileName();
//         return;
//     }

//     QByteArray data = file.readAll();
//     file.close();

//     QJsonDocument doc = QJsonDocument::fromJson(data);
//     if (!doc.isObject()) {
//         qWarning() << "Invalid JSON format";
//         return;
//     }

//     QJsonObject obj = doc.object();
//     if (obj.contains("adaptiveStatus")) {
//         setAdaptiveStatus(obj["adaptiveStatus"].toInt());
//     }
// }
