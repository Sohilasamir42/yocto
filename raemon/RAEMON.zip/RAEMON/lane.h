// // #ifndef LANE_H
// // #define LANE_H

// // #include <QObject>

// // class Lane : public QObject {
// //     Q_OBJECT
// //     Q_PROPERTY(int laneStatus READ laneStatus WRITE setLaneStatus NOTIFY laneStatusChanged)

// // public:
// //     explicit Lane(QObject *parent = nullptr);

// //     int laneStatus() const;
// //     void setLaneStatus(int status);

// // signals:
// //     void laneStatusChanged();

// // private:
// //     int m_laneStatus; // 0 = off, 1 = on
// // };

// // #endif // LANE_H


// #ifndef LANE_H
// #define LANE_H

// #include <QObject>

// class Lane : public QObject {
//     Q_OBJECT
//     Q_PROPERTY(int laneStatus READ laneStatus WRITE setLaneStatus NOTIFY laneStatusChanged)

// public:
//     explicit Lane(QObject *parent = nullptr);

//     int laneStatus() const;
//     void setLaneStatus(int status);

//     Q_INVOKABLE void saveLaneStatus();
//     Q_INVOKABLE void loadLaneStatus();

// signals:
//     void laneStatusChanged();

// private:
//     int m_laneStatus; // 0 = off, 1 = on
// };

// #endif // LANE_H
