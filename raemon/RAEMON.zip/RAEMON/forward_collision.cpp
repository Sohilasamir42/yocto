// //  #include "forward_collision.h"

// // // forward_collision::forward_collision() {}



// // ForwardCollision::ForwardCollision(QObject *parent)
// //     : QObject(parent), m_collisionStatus(0) {}

// // int ForwardCollision::collisionStatus() const {
// //     return m_collisionStatus;
// // }

// // void ForwardCollision::setCollisionStatus(int status) {
// //     if (m_collisionStatus != status) {
// //         m_collisionStatus = status;
// //         emit collisionStatusChanged();
// //     }
// // }

// //  #include "forward_collision.h"

// // // forward_collision::forward_collision() {}



// // ForwardCollision::ForwardCollision(QObject *parent)
// //     : QObject(parent), m_collisionStatus(0) {}

// // int ForwardCollision::collisionStatus() const {
// //     return m_collisionStatus;
// // }

// // void ForwardCollision::setCollisionStatus(int status) {
// //     if (m_collisionStatus != status) {
// //         m_collisionStatus = status;
// //         emit collisionStatusChanged();
// //     }
// // }

// //  #include "forward_collision.h"

// // // forward_collision::forward_collision() {}



// // ForwardCollision::ForwardCollision(QObject *parent)
// //     : QObject(parent), m_collisionStatus(0) {}

// // int ForwardCollision::collisionStatus() const {
// //     return m_collisionStatus;
// // }

// // void ForwardCollision::setCollisionStatus(int status) {
// //     if (m_collisionStatus != status) {
// //         m_collisionStatus = status;
// //         emit collisionStatusChanged();
// //     }
// // }

// //  #include "forward_collision.h"

// // // forward_collision::forward_collision() {}



// // ForwardCollision::ForwardCollision(QObject *parent)
// //     : QObject(parent), m_collisionStatus(0) {}

// // int ForwardCollision::collisionStatus() const {
// //     return m_collisionStatus;
// // }

// // void ForwardCollision::setCollisionStatus(int status) {
// //     if (m_collisionStatus != status) {
// //         m_collisionStatus = status;
// //         emit collisionStatusChanged();
// //     }
// // }

// #include "forward_collision.h"
// #include <QFile>
// #include <QJsonDocument>
// #include <QJsonObject>
// #include <QDebug>
// #include <QStandardPaths>
// #include <QDir>

// ForwardCollision::ForwardCollision(QObject *parent)
//     : QObject(parent)
// {
// }

// int ForwardCollision::collisionStatus() const
// {
//     return m_collisionStatus;
// }

// void ForwardCollision::setCollisionStatus(int status)
// {
//     if (m_collisionStatus != status) {
//         m_collisionStatus = status;
//         emit collisionStatusChanged();
//     }
// }

// void ForwardCollision::saveCollisionStatus()
// {
//     // Get the path to a suitable directory (e.g., the user's document directory)
//     QString path = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
//     QDir dir(path);

//     // Create the directory if it does not exist
//     if (!dir.exists()) {
//         dir.mkpath(".");
//     }

//     // Define the full path to the file
//     QFile file(dir.filePath("forward_flags.json"));

//     if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
//         qWarning() << "Failed to open file for writing at" << file.fileName();
//         return;
//     }
//     qDebug() << "Saving to:" << file.fileName();


//     QJsonObject obj;
//     obj["collisionStatus"] = m_collisionStatus;

//     QJsonDocument doc(obj);
//     file.write(doc.toJson());
//     file.close();
// }

// void ForwardCollision::loadCollisionStatus()
// {
//     // Get the path to a suitable directory (e.g., the user's document directory)
//     QString path = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
//     QFile file(QDir(path).filePath("forward_flags.json"));

//     // Check if the file exists
//     if (!file.exists()) {
//         qWarning() << "File does not exist. Creating a new file.";
//         saveCollisionStatus();  // This will create the file and write default values
//         return;
//     }

//     if (!file.open(QIODevice::ReadOnly)) {
//         qWarning() << "Failed to open file for reading at" << file.fileName();
//         return;
//     }

//     QByteArray data = file.readAll();
//     file.close();

//     QJsonDocument doc = QJsonDocument::fromJson(data);
//     if (!doc.isObject()) {
//         qWarning() << "Invalid JSON format";
//         return;
//     }

//     QJsonObject obj = doc.object();
//     if (obj.contains("collisionStatus")) {
//         setCollisionStatus(obj["collisionStatus"].toInt());
//     }
// }
