# Raemon Layout Concept: 
![Home](https://github.com/cppqtdev/RAEMON/blob/main/layout-screenshots/layout-1.png)
![Car](https://github.com/cppqtdev/RAEMON/blob/main/layout-screenshots/layout-2.png)
![Navigation](https://github.com/cppqtdev/RAEMON/blob/main/layout-screenshots/layout-3.png)
![Thermo](https://github.com/cppqtdev/RAEMON/blob/main/layout-screenshots/layout-4.png)
![Music](https://github.com/cppqtdev/RAEMON/blob/main/layout-screenshots/layout-5.png)

# RAEMON UI SCREENS : 
![UI](https://github.com/cppqtdev/RAEMON/blob/main/screenshots/0.png)
![UI](https://github.com/cppqtdev/RAEMON/blob/main/screenshots/1.png)
![UI](https://github.com/cppqtdev/RAEMON/blob/main/screenshots/2.png)
![UI](https://github.com/cppqtdev/RAEMON/blob/main/screenshots/3.png)
![UI](https://github.com/cppqtdev/RAEMON/blob/main/screenshots/4.png)
![UI](https://github.com/cppqtdev/RAEMON/blob/main/screenshots/5.png)
![UI](https://github.com/cppqtdev/RAEMON/blob/main/screenshots/6.png)
![UI](https://github.com/cppqtdev/RAEMON/blob/main/screenshots/7.png)
![UI](https://github.com/cppqtdev/RAEMON/blob/main/screenshots/8.png)
![UI](https://github.com/cppqtdev/RAEMON/blob/main/screenshots/9.png)
![UI](https://github.com/cppqtdev/RAEMON/blob/main/screenshots/10.png)
![UI](https://github.com/cppqtdev/RAEMON/blob/main/screenshots/11.png)
![UI](https://github.com/cppqtdev/RAEMON/blob/main/screenshots/12.png)
![UI](https://github.com/cppqtdev/RAEMON/blob/main/screenshots/13.png)
![UI](https://github.com/cppqtdev/RAEMON/blob/main/screenshots/14.png)
![UI](https://github.com/cppqtdev/RAEMON/blob/main/screenshots/15.png)
![UI](https://github.com/cppqtdev/RAEMON/blob/main/screenshots/16.png)




## Figma URL
![Figma URL](https://www.figma.com/design/TnfgSUpsAM6lcpu1r5iuXm/Electric-Car-Console-UI-Design?node-id=108-1203&t=hpdQh6sCITeI619F-0)
