#ifndef FEATURES_H
#define FEATURES_H

#include <QObject>

class Features : public QObject
{
    Q_OBJECT
    Q_PROPERTY(int adaptiveStatus READ adaptiveStatus WRITE setAdaptiveStatus NOTIFY adaptiveStatusChanged)
    Q_PROPERTY(int collisionStatus READ collisionStatus WRITE setCollisionStatus NOTIFY collisionStatusChanged)
    Q_PROPERTY(int laneStatus READ laneStatus WRITE setLaneStatus NOTIFY laneStatusChanged)

public:
    explicit Features(QObject *parent = nullptr);

    int adaptiveStatus() const;
    void setAdaptiveStatus(int status);

    int collisionStatus() const;
    void setCollisionStatus(int status);

    int laneStatus() const;
    void setLaneStatus(int status);

    Q_INVOKABLE void saveFeatures();
    Q_INVOKABLE void loadFeatures();

signals:
    void adaptiveStatusChanged();
    void collisionStatusChanged();
    void laneStatusChanged();

private:
    int m_adaptiveStatus = 0;
    int m_collisionStatus = 0;
    int m_laneStatus = 0;
};

#endif // FEATURES_H
